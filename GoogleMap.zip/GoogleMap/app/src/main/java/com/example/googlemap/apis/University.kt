package com.thanushaw.university_locations_219.apis

import com.google.android.gms.maps.model.LatLng

data class University(val name: String, val coordinates: LatLng)